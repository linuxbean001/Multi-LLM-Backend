<div class="flex items-center justify-end mt-4">
    <a class="ml-1 btn btn-primary" href="{{ url('auth/facebook') }}" style="margin-top: 0px !important;background: blue;color: #ffffff;padding: 5px;border-radius:7px;" id="btn-fblogin">
        <i class="fa fa-facebook-square" aria-hidden="true"></i> Login with Facebook
    </a>
</div>