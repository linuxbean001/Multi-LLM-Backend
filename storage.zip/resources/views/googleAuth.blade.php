<div class="flex items-center justify-end mt-4">
    <a class="btn" href="{{ url('auth/google') }}" style="background: #9e49ff; color: #ffffff; padding: 10px; width: 100%; text-align: center; display: block; border-radius:3px;">
        Login with Google
    </a>
</div>